# QuantumBot v2.0 ufficiale

Versione 2.0 ufficiale basata sulla v1.0.21 modulare testata e promossa.

Obiettivo: separare il codice in file più leggibili senza cambiare funzionalità.

File principali:

- `QuantumBot_v2_0.py` → launcher principale per VS Code / Terminale / PyInstaller
- `quantumbot/settings.py` → import, percorsi, config, utility, log, modalità trading
- `quantumbot/widgets.py` → widget custom Tkinter arrotondati
- `quantumbot/database.py` → SQLite, CSV, report, grafici PNG
- `quantumbot/engine.py` → engine, comandi, mercato, strategia, trading simulato
- `quantumbot/dashboard.py` → dashboard Tkinter
- `quantumbot/app.py` → main runtime e opzioni CLI

Funzioni da preservare dalla v1.0.19:

- Vendi EUR libero
- Vendi 25/50/75/100
- Compra manuale
- Auto Trade RSI
- Auto Profit/Loss
- EngineGuard
- FeeAware
- MaxPositionsFix
- AutoCharts sempre attivo
- SQLite/CSV/report/grafici
- Dashboard esistente

Comandi test:

```bash
python3 -m py_compile QuantumBot_v2_0.py quantumbot/*.py
python3 QuantumBot_v2_0.py --sync --report --charts
python3 QuantumBot_v2_0.py
```

Creazione app macOS:

```bash
python3 -m PyInstaller --onedir --windowed --name QuantumBot QuantumBot_v2_0.py
```


## Micro-fix watchlist

Questa build mantiene la struttura modulare v2.0 ufficiale e allinea il flag `has_position` della watchlist allo stato reale delle posizioni in `config.json`, evitando residui visivi dopo una liquidazione totale manuale.


## v2.0 SQLite final position snapshot fix

Micro-fix conservativo: dopo comandi dashboard e prima del report finale, SQLite viene riallineato allo stato reale di `config.json`, così `current_positions` ed `equity_snapshots` non restano indietro dopo liquidazione totale manuale.


## Stato release

Questa è la versione 2.0 ufficiale: deriva dalla v1.0.21 modulare SQLite fix, già testata su CSV/SQLite, EngineGuard, FeeAware, MaxPositionsFix, AutoCharts, Vendi EUR e chiusura/liquidazione finale.
